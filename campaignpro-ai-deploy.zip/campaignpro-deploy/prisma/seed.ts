import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Create test access codes
  const codes = [
    { code: 'CAMPAIGNPRO123', plan: 'lifetime' },
    { code: 'CAMPAIGNPRO2024', plan: 'lifetime' },
    { code: 'CPTESTAGENCY', plan: 'agency' },
    { code: 'CPLIFETIME001', plan: 'lifetime' },
    { code: 'CPAGENCY001', plan: 'agency' },
  ];

  for (const codeData of codes) {
    try {
      const code = await prisma.accessCode.create({
        data: codeData
      });
      console.log(`Created code: ${code.code} (${code.plan})`);
    } catch (error) {
      console.log(`Code ${codeData.code} already exists or error occurred`);
    }
  }

  console.log('\nSeeding completed!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
