'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Zap, 
  Crown, 
  Check, 
  Star, 
  Rocket, 
  Target, 
  TrendingUp, 
  Users, 
  Globe, 
  Shield, 
  Clock,
  CreditCard,
  Smartphone,
  Building2,
  Copy,
  Download,
  Sparkles,
  ChevronRight,
  Play,
  Menu,
  X
} from 'lucide-react';

interface CampaignDay {
  day: number;
  platform: string;
  hook: string;
  caption: string;
  cta: string;
  hashtags: string[];
  imagePrompt?: string;
}

export default function CampaignProApp() {
  const [activeSection, setActiveSection] = useState('home');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [accessCode, setAccessCode] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<'lifetime' | 'agency'>('lifetime');
  const [niche, setNiche] = useState('');
  const [goal, setGoal] = useState('grow_followers');
  const [campaign, setCampaign] = useState<CampaignDay[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Check for stored access on mount
  useEffect(() => {
    const storedAccess = localStorage.getItem('campaignpro_access');
    if (storedAccess === 'granted') {
      setIsUnlocked(true);
      setActiveSection('generator');
    }
  }, []);

  const handleVerifyCode = async () => {
    setError('');
    setSuccess('');
    
    if (!accessCode.trim()) {
      setError('Please enter an access code');
      return;
    }
    
    try {
      const response = await fetch('/api/verify-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: accessCode.trim() }),
      });
      
      const data = await response.json();
      
      if (response.ok && data.success) {
        setIsUnlocked(true);
        localStorage.setItem('campaignpro_access', 'granted');
        setSuccess('Access granted! Welcome to CampaignPro AI');
        setActiveSection('generator');
      } else {
        setError(data.error || 'Invalid access code');
      }
    } catch {
      setError('Failed to verify access code. Please try again.');
    }
  };

  const handleGenerateCampaign = async () => {
    if (!niche.trim()) {
      setError('Please enter your niche or topic');
      return;
    }
    
    setIsGenerating(true);
    setError('');
    
    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ niche, goal, useAI: true }),
      });
      
      const data = await response.json();
      
      if (response.ok && data.success) {
        setCampaign(data.campaign);
        setSuccess('Campaign generated successfully!');
      } else {
        setError(data.error || 'Failed to generate campaign');
      }
    } catch {
      setError('Failed to generate campaign. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setSuccess('Copied to clipboard!');
    setTimeout(() => setSuccess(''), 2000);
  };

  const exportCampaign = () => {
    const content = campaign.map(day => 
      `Day ${day.day} - ${day.platform}\n` +
      `Hook: ${day.hook}\n` +
      `Caption: ${day.caption}\n` +
      `CTA: ${day.cta}\n` +
      `Hashtags: ${day.hashtags.join(' ')}\n\n`
    ).join('---\n\n');
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `campaign-${niche.replace(/\s+/g, '-')}-30days.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const scrollToSection = (section: string) => {
    setActiveSection(section);
    setMobileMenuOpen(false);
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-900/95 backdrop-blur-sm border-b border-slate-700/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-cyan-500 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-slate-900" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
                CampaignPro AI
              </span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-6">
              <button 
                onClick={() => scrollToSection('home')}
                className="text-slate-300 hover:text-white transition-colors"
              >
                Home
              </button>
              <button 
                onClick={() => scrollToSection('features')}
                className="text-slate-300 hover:text-white transition-colors"
              >
                Features
              </button>
              <button 
                onClick={() => scrollToSection('pricing')}
                className="text-slate-300 hover:text-white transition-colors"
              >
                Pricing
              </button>
              <Button 
                onClick={() => scrollToSection('pricing')}
                className="bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-slate-900 font-semibold"
              >
                Get Started
              </Button>
            </div>
            
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden text-white"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-slate-800 border-b border-slate-700">
            <div className="px-4 py-4 space-y-3">
              <button 
                onClick={() => scrollToSection('home')}
                className="block w-full text-left text-slate-300 hover:text-white py-2"
              >
                Home
              </button>
              <button 
                onClick={() => scrollToSection('features')}
                className="block w-full text-left text-slate-300 hover:text-white py-2"
              >
                Features
              </button>
              <button 
                onClick={() => scrollToSection('pricing')}
                className="block w-full text-left text-slate-300 hover:text-white py-2"
              >
                Pricing
              </button>
              <Button 
                onClick={() => scrollToSection('pricing')}
                className="w-full bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-900 font-semibold"
              >
                Get Started
              </Button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center py-16 sm:py-24">
            <Badge className="mb-6 bg-emerald-500/10 text-emerald-400 border-emerald-500/20 px-4 py-1">
              <Sparkles className="w-4 h-4 mr-2" />
              AI-Powered Campaign Generator
            </Badge>
            
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
              Turn One Idea Into{' '}
              <span className="bg-gradient-to-r from-emerald-400 via-cyan-400 to-teal-400 bg-clip-text text-transparent">
                30 Days of Content
              </span>
            </h1>
            
            <p className="text-lg sm:text-xl text-slate-400 max-w-3xl mx-auto mb-8">
              CampaignPro AI generates complete 30-day social media campaigns with hooks, captions, 
              CTAs, and hashtags for TikTok, Instagram, Pinterest, X, YouTube Shorts, and LinkedIn.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                onClick={() => scrollToSection('pricing')}
                className="bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-slate-900 font-semibold text-lg px-8 py-6"
              >
                <Rocket className="w-5 h-5 mr-2" />
                Start Creating Now
              </Button>
              <Button 
                size="lg"
                variant="outline"
                onClick={() => scrollToSection('features')}
                className="border-slate-600 text-white hover:bg-slate-800 text-lg px-8 py-6"
              >
                <Play className="w-5 h-5 mr-2" />
                See How It Works
              </Button>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-16 max-w-4xl mx-auto">
              {[
                { value: '10K+', label: 'Campaigns Created' },
                { value: '50+', label: 'Niche Categories' },
                { value: '6', label: 'Social Platforms' },
                { value: '30', label: 'Days of Content' },
              ].map((stat, i) => (
                <div key={i} className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                  <div className="text-2xl sm:text-3xl font-bold text-emerald-400">{stat.value}</div>
                  <div className="text-sm text-slate-400">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 px-4 sm:px-6 lg:px-8 bg-slate-800/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Everything You Need to{' '}
              <span className="text-emerald-400">Dominate Social Media</span>
            </h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Stop struggling with content ideas. Let AI create your entire campaign in seconds.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: Target,
                title: 'Instant Campaign Generation',
                description: 'Enter your niche and get a complete 30-day campaign with viral hooks, engaging captions, and powerful CTAs tailored to your audience.'
              },
              {
                icon: Globe,
                title: 'Multi-Platform Support',
                description: 'Get optimized content for TikTok, Instagram, Pinterest, X (Twitter), YouTube Shorts, and LinkedIn. Each post is crafted for maximum engagement on its platform.'
              },
              {
                icon: Sparkles,
                title: 'AI-Enhanced Content',
                description: 'Our AI analyzes trending patterns and generates hooks designed to capture attention in the first 3 seconds - the key to viral content.'
              },
              {
                icon: TrendingUp,
                title: 'Trending Hashtags',
                description: 'Get platform-specific and niche-relevant hashtags that increase discoverability and help your content reach the right audience.'
              },
              {
                icon: Clock,
                title: 'Save 100+ Hours',
                description: 'What normally takes weeks of planning and content creation is done in seconds. Focus on execution while we handle the strategy.'
              },
              {
                icon: Users,
                title: 'Perfect for Creators & Agencies',
                description: 'Whether you\'re a solo creator or managing multiple clients, CampaignPro AI scales with your needs and delivers consistent quality.'
              },
            ].map((feature, i) => (
              <Card key={i} className="bg-slate-800/50 border-slate-700/50 hover:border-emerald-500/50 transition-all duration-300">
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 rounded-lg flex items-center justify-center mb-4">
                    <feature.icon className="w-6 h-6 text-emerald-400" />
                  </div>
                  <CardTitle className="text-white">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-slate-400 text-base">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              How It <span className="text-emerald-400">Works</span>
            </h2>
            <p className="text-slate-400">Three simple steps to your complete social media campaign</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: '01', title: 'Choose Your Plan', description: 'Select Lifetime access for personal use or Agency plan for unlimited campaigns.' },
              { step: '02', title: 'Enter Your Niche', description: 'Tell us about your business, product, or topic. Set your goal - grow followers, sell products, or promote services.' },
              { step: '03', title: 'Get Your Campaign', description: 'Instantly receive 30 days of ready-to-post content for all major platforms.' },
            ].map((item, i) => (
              <div key={i} className="relative">
                <div className="text-6xl font-bold text-slate-700/50 mb-4">{item.step}</div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-slate-400">{item.description}</p>
                {i < 2 && (
                  <ChevronRight className="hidden md:block absolute top-1/2 -right-6 w-6 h-6 text-emerald-500" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-16 px-4 sm:px-6 lg:px-8 bg-slate-800/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Simple, <span className="text-emerald-400">Transparent</span> Pricing
            </h2>
            <p className="text-slate-400">Choose the plan that fits your needs</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Lifetime Plan */}
            <Card className={`relative bg-slate-800/50 border-slate-700/50 ${selectedPlan === 'lifetime' ? 'ring-2 ring-emerald-500' : ''}`}>
              <CardHeader>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <Zap className="w-6 h-6 text-emerald-400" />
                  Lifetime Access
                </CardTitle>
                <div className="mt-4">
                  <span className="text-5xl font-bold">$29</span>
                  <span className="text-slate-400 ml-2">one-time</span>
                </div>
                <CardDescription className="text-slate-400 mt-2">
                  Perfect for creators and small businesses
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {[
                    'Unlimited campaign generations',
                    'All 6 social platforms',
                    'AI-enhanced content',
                    'Export campaigns',
                    'Lifetime access',
                    'No recurring fees',
                  ].map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-slate-300">
                      <Check className="w-5 h-5 text-emerald-400" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button 
                  className="w-full bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-slate-900 font-semibold"
                  onClick={() => setSelectedPlan('lifetime')}
                >
                  Select Plan
                </Button>
              </CardContent>
            </Card>
            
            {/* Agency Plan */}
            <Card className={`relative bg-slate-800/50 border-slate-700/50 ${selectedPlan === 'agency' ? 'ring-2 ring-emerald-500' : ''}`}>
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <Badge className="bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-900">
                  <Star className="w-3 h-3 mr-1" />
                  Most Popular
                </Badge>
              </div>
              <CardHeader>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <Crown className="w-6 h-6 text-yellow-400" />
                  Agency Plan
                </CardTitle>
                <div className="mt-4">
                  <span className="text-5xl font-bold">$99</span>
                  <span className="text-slate-400 ml-2">one-time</span>
                </div>
                <CardDescription className="text-slate-400 mt-2">
                  For agencies and marketing professionals
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {[
                    'Everything in Lifetime',
                    'Priority AI processing',
                    'White-label exports',
                    'Multiple client campaigns',
                    'Commercial license',
                    'Priority support',
                  ].map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-slate-300">
                      <Check className="w-5 h-5 text-emerald-400" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button 
                  className="w-full bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-slate-900 font-semibold"
                  onClick={() => setSelectedPlan('agency')}
                >
                  Select Plan
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Payment Section */}
          <div className="max-w-2xl mx-auto mt-12">
            <Card className="bg-slate-800/50 border-slate-700/50">
              <CardHeader>
                <CardTitle className="text-xl flex items-center gap-2">
                  <Shield className="w-5 h-5 text-emerald-400" />
                  Payment Methods
                </CardTitle>
                <CardDescription>
                  Choose your preferred payment method. All payments are verified manually.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="mpesa" className="w-full">
                  <TabsList className="grid w-full grid-cols-4 bg-slate-700/50">
                    <TabsTrigger value="mpesa" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-slate-900">
                      <Smartphone className="w-4 h-4 mr-1" />
                      M-Pesa
                    </TabsTrigger>
                    <TabsTrigger value="bank" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-slate-900">
                      <Building2 className="w-4 h-4 mr-1" />
                      Bank
                    </TabsTrigger>
                    <TabsTrigger value="paypal" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-slate-900">
                      <CreditCard className="w-4 h-4 mr-1" />
                      PayPal
                    </TabsTrigger>
                    <TabsTrigger value="card" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-slate-900">
                      <CreditCard className="w-4 h-4 mr-1" />
                      Card
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="mpesa" className="mt-4">
                    <div className="bg-slate-700/30 rounded-lg p-4 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400">Amount:</span>
                        <span className="text-xl font-bold text-emerald-400">
                          {selectedPlan === 'lifetime' ? 'KES 3,777' : 'KES 12,870'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400">M-Pesa Number:</span>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => copyToClipboard('+254741834315')}
                          className="text-white hover:text-emerald-400"
                        >
                          +254741834315
                          <Copy className="w-4 h-4 ml-2" />
                        </Button>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400">Account Name:</span>
                        <span className="text-white">Edwin Ochanga Ogamba</span>
                      </div>
                      <Alert className="bg-emerald-500/10 border-emerald-500/20 mt-4">
                        <AlertDescription className="text-emerald-300">
                          Send payment via M-Pesa, then contact us with your transaction ID to receive your access code.
                        </AlertDescription>
                      </Alert>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="bank" className="mt-4">
                    <div className="bg-slate-700/30 rounded-lg p-4 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400">Amount:</span>
                        <span className="text-xl font-bold text-emerald-400">
                          {selectedPlan === 'lifetime' ? '$29 USD' : '$99 USD'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400">Bank:</span>
                        <span className="text-white">Equity Bank</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400">Account Number:</span>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => copyToClipboard('0630182883708')}
                          className="text-white hover:text-emerald-400"
                        >
                          0630182883708
                          <Copy className="w-4 h-4 ml-2" />
                        </Button>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400">Account Name:</span>
                        <span className="text-white">Edwin Ochanga Ogamba</span>
                      </div>
                      <Alert className="bg-emerald-500/10 border-emerald-500/20 mt-4">
                        <AlertDescription className="text-emerald-300">
                          After bank transfer, send proof of payment to receive your access code.
                        </AlertDescription>
                      </Alert>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="paypal" className="mt-4">
                    <div className="bg-slate-700/30 rounded-lg p-4 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400">Amount:</span>
                        <span className="text-xl font-bold text-emerald-400">
                          {selectedPlan === 'lifetime' ? '$29 USD' : '$99 USD'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400">PayPal Email:</span>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => copyToClipboard('ochangaedwin147@gmail.com')}
                          className="text-white hover:text-emerald-400"
                        >
                          ochangaedwin147@gmail.com
                          <Copy className="w-4 h-4 ml-2" />
                        </Button>
                      </div>
                      <Alert className="bg-emerald-500/10 border-emerald-500/20 mt-4">
                        <AlertDescription className="text-emerald-300">
                          Send payment via PayPal, then contact us with your transaction ID to receive your access code.
                        </AlertDescription>
                      </Alert>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="card" className="mt-4">
                    <div className="bg-slate-700/30 rounded-lg p-4 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400">Amount:</span>
                        <span className="text-xl font-bold text-emerald-400">
                          {selectedPlan === 'lifetime' ? '$29 USD' : '$99 USD'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400">Bank Transfer:</span>
                        <span className="text-white">Equity Bank Kenya</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400">Account:</span>
                        <span className="text-white">0630182883708</span>
                      </div>
                      <Alert className="bg-emerald-500/10 border-emerald-500/20 mt-4">
                        <AlertDescription className="text-emerald-300">
                          International card payments are processed via bank transfer. Send proof of payment to receive your access code.
                        </AlertDescription>
                      </Alert>
                    </div>
                  </TabsContent>
                </Tabs>
                
                <div className="mt-6 p-4 bg-slate-700/30 rounded-lg">
                  <h4 className="font-semibold mb-2">After Payment:</h4>
                  <p className="text-slate-400 text-sm">
                    Send your transaction ID/proof of payment to receive your unique access code. 
                    Codes are delivered within 24 hours of payment confirmation.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Access Code Input */}
          <div className="max-w-md mx-auto mt-8">
            <Card className="bg-slate-800/50 border-slate-700/50">
              <CardHeader>
                <CardTitle className="text-lg">Already Paid? Enter Your Access Code</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter access code"
                    value={accessCode}
                    onChange={(e) => setAccessCode(e.target.value)}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500"
                  />
                  <Button 
                    onClick={handleVerifyCode}
                    className="bg-emerald-500 hover:bg-emerald-600 text-white"
                  >
                    Unlock
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Campaign Generator Section */}
      {isUnlocked && (
        <section id="generator" className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <Badge className="mb-4 bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                <Zap className="w-4 h-4 mr-2" />
                AI Campaign Generator
              </Badge>
              <h2 className="text-3xl sm:text-4xl font-bold mb-4">
                Generate Your <span className="text-emerald-400">30-Day Campaign</span>
              </h2>
              <p className="text-slate-400">Enter your niche and goal to generate a complete social media campaign</p>
            </div>
            
            <Card className="max-w-2xl mx-auto bg-slate-800/50 border-slate-700/50">
              <CardHeader>
                <CardTitle>Campaign Settings</CardTitle>
                <CardDescription>Configure your campaign parameters</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="niche">Niche / Topic</Label>
                  <Input
                    id="niche"
                    placeholder="e.g., Digital Marketing, Fitness Coaching, Crypto Trading"
                    value={niche}
                    onChange={(e) => setNiche(e.target.value)}
                    className="bg-slate-700/50 border-slate-600"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="goal">Campaign Goal</Label>
                  <Select value={goal} onValueChange={setGoal}>
                    <SelectTrigger className="bg-slate-700/50 border-slate-600">
                      <SelectValue placeholder="Select your goal" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700">
                      <SelectItem value="grow_followers">Grow Followers</SelectItem>
                      <SelectItem value="sell_product">Sell Product</SelectItem>
                      <SelectItem value="promote_service">Promote Service</SelectItem>
                      <SelectItem value="build_brand">Build Brand Awareness</SelectItem>
                      <SelectItem value="drive_traffic">Drive Website Traffic</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Button 
                  className="w-full bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-slate-900 font-semibold"
                  onClick={handleGenerateCampaign}
                  disabled={isGenerating}
                >
                  {isGenerating ? (
                    <>
                      <div className="w-4 h-4 border-2 border-slate-900 border-t-transparent rounded-full animate-spin mr-2" />
                      Generating Campaign...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate 30-Day Campaign
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Campaign Results */}
      {campaign.length > 0 && (
        <section className="py-8 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
              <div>
                <h3 className="text-2xl font-bold">Your 30-Day Campaign for "{niche}"</h3>
                <p className="text-slate-400">Goal: {goal.replace(/_/g, ' ')}</p>
              </div>
              <Button 
                onClick={exportCampaign}
                className="bg-emerald-500 hover:bg-emerald-600"
              >
                <Download className="w-4 h-4 mr-2" />
                Export Campaign
              </Button>
            </div>
            
            <ScrollArea className="h-[600px] rounded-lg border border-slate-700 bg-slate-800/30">
              <div className="p-4 space-y-4">
                {campaign.map((day) => (
                  <Card key={day.day} className="bg-slate-800/50 border-slate-700/50">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Badge className="bg-emerald-500/20 text-emerald-400">Day {day.day}</Badge>
                          <Badge variant="outline" className="border-slate-600 text-slate-300">{day.platform}</Badge>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => copyToClipboard(`Day ${day.day} - ${day.platform}\nHook: ${day.hook}\nCaption: ${day.caption}\nCTA: ${day.cta}\nHashtags: ${day.hashtags.join(' ')}`)}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <Label className="text-slate-400 text-sm">Hook</Label>
                        <p className="text-white font-medium">{day.hook}</p>
                      </div>
                      <div>
                        <Label className="text-slate-400 text-sm">Caption</Label>
                        <Textarea 
                          value={day.caption} 
                          readOnly 
                          className="bg-slate-700/30 border-slate-600 min-h-[80px]"
                        />
                      </div>
                      <div>
                        <Label className="text-slate-400 text-sm">Call-to-Action</Label>
                        <p className="text-emerald-400">{day.cta}</p>
                      </div>
                      <div>
                        <Label className="text-slate-400 text-sm">Hashtags</Label>
                        <div className="flex flex-wrap gap-2 mt-1">
                          {day.hashtags.map((tag, i) => (
                            <Badge key={i} variant="secondary" className="bg-slate-700 text-slate-300">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </div>
        </section>
      )}

      {/* Error/Success Messages */}
      {(error || success) && (
        <div className="fixed bottom-4 right-4 z-50">
          <Alert className={error ? "bg-red-500/10 border-red-500/20" : "bg-emerald-500/10 border-emerald-500/20"}>
            <AlertDescription className={error ? "text-red-300" : "text-emerald-300"}>
              {error || success}
            </AlertDescription>
          </Alert>
        </div>
      )}

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 bg-slate-900 border-t border-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-cyan-500 rounded-lg flex items-center justify-center">
                  <Zap className="w-6 h-6 text-slate-900" />
                </div>
                <span className="text-xl font-bold">CampaignPro AI</span>
              </div>
              <p className="text-slate-400 text-sm">
                AI-powered social media campaign generator. Build once, sell forever.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><button onClick={() => scrollToSection('features')} className="hover:text-white">Features</button></li>
                <li><button onClick={() => scrollToSection('pricing')} className="hover:text-white">Pricing</button></li>
                <li><button onClick={() => scrollToSection('generator')} className="hover:text-white">Generator</button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>Contact: +254741834315</li>
                <li>Email: support@campaignpro.ai</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Builder</h4>
              <p className="text-slate-400 text-sm">
                <span className="text-white font-medium">Edwin McCain</span><br />
                Creator & Developer<br />
                Kenya 🇰🇪
              </p>
            </div>
          </div>
          
          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-500 text-sm">
            © {new Date().getFullYear()} CampaignPro AI. Built by Edwin McCain. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
