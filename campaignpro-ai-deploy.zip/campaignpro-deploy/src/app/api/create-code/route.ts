import { NextRequest, NextResponse } from 'next/server';
import { randomBytes } from 'crypto';

// Simple in-memory code storage (resets on server restart)
// For production, use a database or environment variables
const generatedCodes: Map<string, { plan: string; createdAt: Date }> = new Map();

// Pre-defined permanent codes
const PERMANENT_CODES: Record<string, string> = {
  'CAMPAIGNPRO123': 'lifetime',
  'CAMPAIGNPRO2024': 'lifetime',
  'CAMPAIGNPRO2025': 'lifetime',
  'CAMPAIGNPRO2026': 'lifetime',
  'CPTESTAGENCY': 'agency',
  'CPLIFETIME001': 'lifetime',
  'CPAGENCY001': 'agency',
  'CPAGENCY002': 'agency',
  'CPAGENCY003': 'agency',
};

function generateAccessCode(): string {
  const prefix = 'CP';
  const random = randomBytes(4).toString('hex').toUpperCase();
  return `${prefix}${random}`;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { plan, adminKey } = body;
    
    // Simple admin protection
    const validAdminKey = process.env.ADMIN_KEY || 'campaignpro_admin_2024';
    
    if (adminKey !== validAdminKey) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    if (!plan || !['lifetime', 'agency'].includes(plan)) {
      return NextResponse.json(
        { error: 'Valid plan (lifetime or agency) is required' },
        { status: 400 }
      );
    }
    
    const code = generateAccessCode();
    generatedCodes.set(code, { plan, createdAt: new Date() });
    
    return NextResponse.json({
      success: true,
      code,
      plan,
      createdAt: new Date().toISOString(),
      note: 'Code stored in memory. Add to PERMANENT_CODES for persistence.'
    });
    
  } catch (error) {
    console.error('Create code error:', error);
    return NextResponse.json(
      { error: 'Failed to create access code' },
      { status: 500 }
    );
  }
}

// GET endpoint to list all codes
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const adminKey = searchParams.get('adminKey');
    
    const validAdminKey = process.env.ADMIN_KEY || 'campaignpro_admin_2024';
    
    if (adminKey !== validAdminKey) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    // Return permanent codes
    const codes = Object.entries(PERMANENT_CODES).map(([code, plan]) => ({
      code,
      plan,
      type: 'permanent'
    }));
    
    // Add generated codes
    generatedCodes.forEach((value, code) => {
      codes.push({
        code,
        plan: value.plan,
        type: 'generated',
        createdAt: value.createdAt.toISOString()
      });
    });
    
    return NextResponse.json({
      success: true,
      totalCodes: codes.length,
      codes
    });
    
  } catch (error) {
    console.error('List codes error:', error);
    return NextResponse.json(
      { error: 'Failed to list access codes' },
      { status: 500 }
    );
  }
}
